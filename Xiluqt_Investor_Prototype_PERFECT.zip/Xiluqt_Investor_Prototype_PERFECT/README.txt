XILUQT — PERFECT INVESTOR PROTOTYPE

Open index.html in a modern browser. Best experience is HTTPS hosting (GitHub Pages, Netlify, Vercel, etc.).

FEATURES
- Xiluqt logo-first cinematic entrance with fail-safe splash removal.
- Real browser GPS via navigator.geolocation.watchPosition(). Requires HTTPS and user permission.
- Live GPS map, speed, altitude, accuracy, timestamp and movement trail.
- OSRM public routing for a live road ETA demo.
- NASA GIBS satellite imagery context.
- Open-Meteo live weather context.
- Open flight-position context using OpenSky best-effort public API.
- Real-time scenario inference: weather, congestion, inventory pressure and confidence alter outcome probabilities.
- Live control plane: signal freshness, signal count, inference latency, decision stream and gateway status.
- API playground and investor demo panels.
- Production architecture blueprint for GPS/telematics/AIS/ADS-B/ERP/TMS ingestion.

IMPORTANT
Public/context APIs are used for demonstration and evaluation. Commercial production requires appropriate licences, quotas, attribution and service agreements. Customer fleet GPS must be authorized by the customer/device owner. Demo fleet values and probabilities must not be represented as validated production ML performance.
